const { EmbedBuilder, MessageFlags, SlashCommandBuilder } = require('discord.js');
const db = require('../db');
const R = require('../rpg/nucleo');
const S = require('../extras/stars');
const PetArte = require('../extras/petarte');

const EPH = MessageFlags.Ephemeral;
const COR = 0xf5a3c7;
const HORA = 3600 * 1000;
const NIVEL_MAX = 20;

const ESPECIES = {
  gato: { emoji: '🐱', nome: 'Gato', preco: 300, desc: 'Sortudo: acha poções com mais frequência.', pocao: 0.25, stars: 1, xp: 1, cd: 60 },
  cachorro: { emoji: '🐶', nome: 'Cachorro', preco: 250, desc: 'Fiel: traz 15% mais stars nos passeios.', pocao: 0.1, stars: 1.15, xp: 1, cd: 60 },
  coelho: { emoji: '🐰', nome: 'Coelho', preco: 200, desc: 'Ligeiro: pode passear a cada 40 minutos.', pocao: 0.1, stars: 1, xp: 1, cd: 40 },
  raposa: { emoji: '🦊', nome: 'Raposa', preco: 400, desc: 'Esperta: ganha 25% mais XP.', pocao: 0.1, stars: 1, xp: 1.25, cd: 60 },
  coruja: { emoji: '🦉', nome: 'Coruja', preco: 500, desc: 'Sábia: mais XP e um pouco mais de stars.', pocao: 0.15, stars: 1.05, xp: 1.2, cd: 60 },
  dragonfox: { emoji: '🦊', nome: 'Dragonfox', preco: 0, exclusivo: true, animado: true, desc: 'ULTRA LENDÁRIO: uma raposa com asas de dragão. +60% de stars, +50% de XP, acha poções e passeia a cada 30 min.', pocao: 0.35, stars: 1.6, xp: 1.5, cd: 30 },
  dragao: { emoji: '🐉', nome: 'Dragãozinho', preco: 1500, desc: 'Lendário: +30% de stars e acha poções.', pocao: 0.2, stars: 1.3, xp: 1.1, cd: 60 },

  // Lendários dark fantasy: caros, mas com os melhores benefícios.
  // jxp = XP que o dono ganha a cada passeio; raro = chance de trazer um material valioso
  corvo: { emoji: '🐦‍⬛', nome: 'Corvo Agourento', preco: 2000, desc: 'Lendário: +25% de stars, +35% de XP, passeia a cada 45 min e traz XP ao dono.', pocao: 0.25, stars: 1.25, xp: 1.35, cd: 45, jxp: 25, raro: { item: 'pena_sombria', chance: 0.1 } },
  lobo: { emoji: '🐺', nome: 'Lobo Espectral', preco: 2800, desc: 'Lendário: +45% de stars, passeia a cada 40 min e traz XP ao dono.', pocao: 0.3, stars: 1.45, xp: 1.25, cd: 40, jxp: 40, raro: { item: 'pena_sombria', chance: 0.15 } },
  fenix: { emoji: '🔥', nome: 'Fênix Carmesim', preco: 3800, desc: 'Lendário: +60% de stars, +40% de XP, passeia a cada 35 min e traz cinzas raras.', pocao: 0.4, stars: 1.6, xp: 1.4, cd: 35, jxp: 60, raro: { item: 'cinza_fenix', chance: 0.18 } },
  wyvern: { emoji: '🐲', nome: 'Wyvern das Trevas', preco: 5000, desc: 'Mítico: +80% de stars, +55% de XP, passeia a cada 30 min e traz XP e fragmentos do vazio.', pocao: 0.45, stars: 1.8, xp: 1.55, cd: 30, jxp: 90, raro: { item: 'fragmento_vazio', chance: 0.2 } },
  quimera: { emoji: '👑', nome: 'Quimera Ancestral', preco: 7000, desc: 'Mítico supremo: dobra as stars, +70% de XP, passeia a cada 25 min e traz muito XP e fragmentos do vazio.', pocao: 0.5, stars: 2.0, xp: 1.7, cd: 25, jxp: 140, raro: { item: 'fragmento_vazio', chance: 0.3 } },
};

// Toda espécie que tem pixel art (em extras/petarte.js ou no bichos.js) mostra a imagem animada
for (const id of Object.keys(ESPECIES)) if (PetArte.tem(id) || ESPECIES[id].animado) ESPECIES[id].animado = true;

// Espécies exclusivas (presentes da staff) não aparecem na lista nem podem ser compradas
const COMPRAVEIS = Object.entries(ESPECIES).filter(([, e]) => !e.exclusivo);

const caminho = (uid) => `extras.pets.${uid}`;
const obter = (uid) => db.get(caminho(uid), null);
const xpNecessario = (n) => 30 + n * 20;
const custoComida = (p) => 15 + p.nivel * 3;
const sorteio = (a, b) => a + Math.floor(Math.random() * (b - a + 1));
const fmtMs = (ms) => {
  const m = Math.ceil(ms / 60000);
  return m >= 60 ? `${Math.floor(m / 60)}h${String(m % 60).padStart(2, '0')}` : `${m} min`;
};

function ganharXpPet(p, qtd) {
  p.xp += qtd;
  let subiu = 0;
  while (p.nivel < NIVEL_MAX && p.xp >= xpNecessario(p.nivel)) {
    p.xp -= xpNecessario(p.nivel);
    p.nivel++;
    subiu++;
  }
  if (p.nivel >= NIVEL_MAX) p.xp = 0;
  return subiu;
}

function embedPet(p, dono) {
  const e = ESPECIES[p.especie];
  const agora = Date.now();
  const saciado = p.alimentadoAte > agora;
  const cd = Math.max(0, (p.cdPasseio || 0) - agora);
  const emb = new EmbedBuilder()
    .setColor(e.exclusivo ? 0xffb347 : COR)
    .setTitle(`${e.emoji} ${p.nome}${e.exclusivo ? ' ✨' : ''}`)
    .setDescription(`${e.nome} de **${dono}**\n_${e.desc}_`)
    .addFields(
      { name: 'Nível', value: `${p.nivel}${p.nivel >= NIVEL_MAX ? ' (máx.)' : ` — ${R.barra(p.xp, xpNecessario(p.nivel), 10)} ${p.xp}/${xpNecessario(p.nivel)}`}` },
      { name: 'Fome', value: saciado ? `😊 Saciado até <t:${Math.floor(p.alimentadoAte / 1000)}:R>` : '😋 Com fome (alimente para passear)', inline: true },
      { name: 'Passeio', value: cd ? `⏳ em ${fmtMs(cd)}` : '✅ disponível', inline: true },
      { name: 'Passeios feitos', value: `${p.passeios || 0}`, inline: true },
    );
  if (e.animado) emb.setImage(PetArte.anexoDe(p.especie, p.nivel).url);
  return emb;
}

// Arquivo da imagem animada (só para espécies que têm)
const arquivosPet = (p) => (ESPECIES[p.especie] && ESPECIES[p.especie].animado ? [PetArte.anexoDe(p.especie, p.nivel).anexo()] : []);

module.exports = {
  ESPECIES,
  embedPet,
  arquivosPet,
  caminho,
  data: new SlashCommandBuilder()
    .setName('pet')
    .setDescription('Seu bichinho de estimação')
    .addSubcommand((s) => s.setName('lista').setDescription('Mostra os bichinhos disponíveis para adotar'))
    .addSubcommand((s) => s.setName('adotar').setDescription('Adota um pet (gasta stars)')
      .addStringOption((o) => o.setName('especie').setDescription('Qual bichinho').setRequired(true)
        .addChoices(...COMPRAVEIS.map(([id, e]) => ({ name: `${e.emoji} ${e.nome} — ${e.preco} stars`, value: id }))))
      .addStringOption((o) => o.setName('nome').setDescription('Nome do pet').setRequired(true).setMaxLength(30)))
    .addSubcommand((s) => s.setName('ver').setDescription('Mostra o pet de alguém')
      .addUserOption((o) => o.setName('membro').setDescription('De quem (padrão: você)')))
    .addSubcommand((s) => s.setName('alimentar').setDescription('Dá comida ao pet (dura 12 horas)'))
    .addSubcommand((s) => s.setName('passear').setDescription('Leva o pet para passear e achar stars'))
    .addSubcommand((s) => s.setName('renomear').setDescription('Muda o nome do pet')
      .addStringOption((o) => o.setName('nome').setDescription('Novo nome').setRequired(true).setMaxLength(30)))
    .addSubcommand((s) => s.setName('soltar').setDescription('Solta o pet (não tem volta!)')
      .addBooleanOption((o) => o.setName('confirmar').setDescription('Marque sim para confirmar').setRequired(true))),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const uid = interaction.user.id;
    const responder = (content) => interaction.reply({ content, flags: EPH });

    if (sub === 'lista') {
      const txt = COMPRAVEIS.map(([, e]) => `${e.emoji} **${e.nome}** — ⭐ ${e.preco}\n${e.desc}`).join('\n\n');
      const vitrine = COMPRAVEIS.map(([id]) => id).filter((id) => PetArte.tem(id));
      const emb = new EmbedBuilder().setColor(COR).setTitle('🐾 Bichinhos para adotar').setDescription(txt).setFooter({ text: 'Use /pet adotar' });
      if (vitrine.length) emb.setImage('attachment://pets.gif');
      return interaction.reply({ embeds: [emb], files: vitrine.length ? [PetArte.vitrine(vitrine)] : [], flags: EPH });
    }

    if (sub === 'ver') {
      const alvo = interaction.options.getUser('membro') || interaction.user;
      const p = obter(alvo.id);
      if (!p) return responder(alvo.id === uid ? 'Você ainda não tem um pet. Veja `/pet lista` e adote com `/pet adotar`.' : 'Essa pessoa ainda não tem um pet.');
      return interaction.reply({ embeds: [embedPet(p, alvo.username)], files: arquivosPet(p) });
    }

    if (sub === 'adotar') {
      if (obter(uid)) return responder('❌ Você já tem um pet. Solte-o com `/pet soltar` se quiser outro.');
      const id = interaction.options.getString('especie');
      const e = ESPECIES[id];
      if (!e || e.exclusivo) return responder('❌ Esse bichinho não está à venda.');
      const r = S.gastar(uid, e.preco);
      if (r.erro) return responder(`❌ ${r.erro}`);
      const p = { especie: id, nome: interaction.options.getString('nome').trim(), nivel: 1, xp: 0, alimentadoAte: Date.now() + 6 * HORA, cdPasseio: 0, passeios: 0, adotadoEm: Date.now() };
      db.set(caminho(uid), p);
      return interaction.reply({ content: `🎉 Você adotou ${e.emoji} **${p.nome}**! Ele já veio alimentado por 6 horas.`, embeds: [embedPet(p, interaction.user.username)], files: arquivosPet(p) });
    }

    const p = obter(uid);
    if (!p) return responder('Você ainda não tem um pet. Veja `/pet lista`.');
    const e = ESPECIES[p.especie];
    const agora = Date.now();

    if (sub === 'renomear') {
      p.nome = interaction.options.getString('nome').trim();
      db.set(caminho(uid), p);
      return responder(`✅ Agora o nome é **${p.nome}**.`);
    }

    if (sub === 'soltar') {
      if (e.exclusivo) return responder('💛 Esse pet é um presente especial e não pode ser solto.');
      if (!interaction.options.getBoolean('confirmar')) return responder('Ufa, o pet continua com você. 💜');
      db.remover(caminho(uid));
      return responder(`👋 ${e.emoji} **${p.nome}** foi solto na natureza.`);
    }

    if (sub === 'alimentar') {
      if (p.alimentadoAte - agora > 6 * HORA) return responder(`😊 ${p.nome} ainda está satisfeito (até <t:${Math.floor(p.alimentadoAte / 1000)}:R>).`);
      const custo = custoComida(p);
      const r = S.gastar(uid, custo);
      if (r.erro) return responder(`❌ ${r.erro}`);
      p.alimentadoAte = Math.max(agora, p.alimentadoAte) + 12 * HORA;
      const subiu = ganharXpPet(p, 5);
      db.set(caminho(uid), p);
      return interaction.reply(`🍖 ${e.emoji} **${p.nome}** comeu muito bem! (⭐ -${custo}, ✨ +5 XP)${subiu ? `\n🎉 Subiu para o nível **${p.nivel}**!` : ''}`);
    }

    if (sub === 'passear') {
      if (p.alimentadoAte <= agora) return responder(`😋 ${p.nome} está com fome! Use \`/pet alimentar\` antes do passeio.`);
      const falta = (p.cdPasseio || 0) - agora;
      if (falta > 0) return responder(`⏳ ${p.nome} está descansando. Volta em ${fmtMs(falta)}.`);
      const j = R.obter(uid);
      if (!j) return responder(S.SEM_RPG);
      const stars = Math.round(sorteio(15, 40) * (1 + (p.nivel - 1) * 0.1) * e.stars);
      const xp = Math.round(sorteio(10, 20) * e.xp);
      j.moedas += stars;
      let extra = '';
      if (Math.random() < e.pocao) {
        R.addItem(j, 'pocao_p', 1);
        extra = '\n🧪 Ele achou uma **Poção Pequena**!';
      }
      if (e.raro && Math.random() < e.raro.chance) {
        R.addItem(j, e.raro.item, 1);
        extra += `\n✨ Ele trouxe um item raro: ${R.nomeItem(e.raro.item)}!`;
      }
      if (e.jxp) {
        const subiuDono = R.ganharXp(j, e.jxp);
        extra += `\n📈 Você ganhou **${e.jxp} XP** com o passeio!${subiuDono ? ` Subiu para o nível **${j.nivel}**! 🎉` : ''}`;
      }
      R.salvar(uid, j);
      p.cdPasseio = agora + e.cd * 60000;
      p.passeios = (p.passeios || 0) + 1;
      const subiu = ganharXpPet(p, xp);
      db.set(caminho(uid), p);
      return interaction.reply(`🌳 ${e.emoji} **${p.nome}** passeou e trouxe ⭐ **${stars}** stars! (✨ +${xp} XP do pet)${extra}${subiu ? `\n🎉 **${p.nome}** subiu para o nível **${p.nivel}**!` : ''}`);
    }
  },
};
// fim do arquivo
