// Quem é "o mesmo personagem". É aqui que mora a correção do bug da vaga ocupada contada como livre.
//
// Antes, a recepção cadastrava por nome (sem obra) e o /vaga pedir por AniList (nome + obra).
// Os dois nunca se reconheciam: a vaga ocupada ficava invisível e o personagem aparecia como livre.
// Agora todo mundo usa mesmoPersonagem(), que ignora ordem das palavras, acento e obra em branco.
const { norm } = require('./util');
const { todas } = require('./banco');

// Chave estável de um personagem: AniList (al:123) ou manual (m:nome|obra)
const chaveManual = (nome, obra) => `m:${norm(nome)}|${norm(obra)}`;

// "Naruto Uzumaki" e "Uzumaki Naruto" viram a mesma coisa
const cacheBase = new Map();
function nomeBase(nome) {
  const k = String(nome || '');
  let b = cacheBase.get(k);
  if (b === undefined) {
    b = norm(k).replace(/[^\p{L}\p{N}\s]/gu, ' ').split(/\s+/).filter(Boolean).sort().join(' ');
    if (cacheBase.size > 5000) cacheBase.clear();
    cacheBase.set(k, b);
  }
  return b;
}

// a e b são { ext, nome, grupo }. Na dúvida (obra em branco) trata como o mesmo personagem:
// é melhor mostrar "ocupado" por engano do que entregar um personagem que já tem dono.
function mesmoPersonagem(a, b) {
  if (!a || !b) return false;
  if (a.ext && b.ext) {
    if (a.ext === b.ext) return true;
    if (a.ext.startsWith('al:') && b.ext.startsWith('al:')) return false; // ids diferentes no AniList = personagens diferentes
  }
  const nome = nomeBase(a.nome);
  if (!nome || nome !== nomeBase(b.nome)) return false;
  const ga = norm(a.grupo);
  const gb = norm(b.grupo);
  return !ga || !gb || ga === gb;
}

const acharTodos = (alvo) => todas().filter((v) => mesmoPersonagem(v, alvo));

// Se existir mais de uma entrada do personagem, devolve a OCUPADA primeiro.
function acharPorChave(chave, nome, grupo) {
  const iguais = acharTodos({ ext: chave, nome, grupo });
  return iguais.find((v) => v.ocupanteId) || iguais[0] || null;
}

// Livre de verdade: sem dono e sem nenhuma entrada gêmea ocupada
function estaLivre(vaga) {
  if (vaga.ocupanteId) return false;
  return !acharTodos(vaga).some((v) => v.ocupanteId);
}

function livres() {
  const lista = todas();
  const ocupadas = lista.filter((v) => v.ocupanteId);
  return lista.filter((v) => !v.ocupanteId && !ocupadas.some((o) => mesmoPersonagem(o, v)));
}

module.exports = { chaveManual, nomeBase, mesmoPersonagem, acharTodos, acharPorChave, estaLivre, livres };
