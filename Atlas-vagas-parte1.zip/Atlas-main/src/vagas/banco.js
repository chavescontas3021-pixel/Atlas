// Leitura e gravação das vagas e dos pedidos no banco.
const db = require('../db');
const { norm } = require('./util');

const todas = () => Object.values(db.get('vagas.lista', {}) || {}).sort((a, b) => Number(a.id) - Number(b.id));
const obter = (id) => db.get(`vagas.lista.${id}`, null);
const salvar = (v) => db.set(`vagas.lista.${v.id}`, v);
const apagar = (id) => db.remover(`vagas.lista.${id}`);
const doUsuario = (uid) => todas().filter((v) => v.ocupanteId === uid);

function proximoId() {
  const n = db.get('vagas.contador', 0) + 1;
  db.set('vagas.contador', n);
  return String(n);
}

const pedidos = () => Object.values(db.get('vagas.pedidos', {}) || {});
const pedido = (id) => db.get(`vagas.pedidos.${id}`, null);

function proximoPedido() {
  const n = db.get('vagas.contadorPedidos', 0) + 1;
  db.set('vagas.contadorPedidos', n);
  return String(n);
}

// Acha pelo id ou pelo nome exato (usado pelos comandos que recebem o id do autocomplete)
function acharVaga(ref) {
  if (!ref) return null;
  const r = norm(ref);
  return todas().find((v) => v.id === String(ref) || norm(v.nome) === r) || null;
}

module.exports = { todas, obter, salvar, apagar, doUsuario, proximoId, pedidos, pedido, proximoPedido, acharVaga };
