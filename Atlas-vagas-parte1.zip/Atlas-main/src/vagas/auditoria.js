// Auditoria: acha personagens cadastrados em duplicidade (a origem do bug) e arruma o que for seguro.
const db = require('../db');
const { todas, apagar, pedidos } = require('./banco');
const { mesmoPersonagem } = require('./identidade');

// Agrupa as entradas que são o mesmo personagem
function grupos(lista) {
  const visto = new Set();
  const saida = [];
  for (const v of lista) {
    if (visto.has(v.id)) continue;
    const comp = [];
    const fila = [v];
    visto.add(v.id);
    while (fila.length) {
      const atual = fila.pop();
      comp.push(atual);
      for (const o of lista) {
        if (!visto.has(o.id) && mesmoPersonagem(atual, o)) { visto.add(o.id); fila.push(o); }
      }
    }
    if (comp.length > 1) saida.push(comp.sort((a, b) => Number(a.id) - Number(b.id)));
  }
  return saida;
}

const pontos = (v) => (v.ext && v.ext.startsWith('al:') ? 4 : 0) + (v.foto ? 2 : 0) + (v.grupo ? 1 : 0);

// corrigir=false só relata. corrigir=true:
//  - junta as entradas livres repetidas;
//  - apaga a livre que é gêmea de uma ocupada (passando obra/foto/AniList para a ocupada);
//  - NUNCA mexe quando duas pessoas diferentes ocupam o mesmo personagem (vira "conflito" para a staff decidir).
function auditar({ corrigir = false } = {}) {
  const rel = { grupos: 0, removidas: [], conflitos: [] };
  for (const comp of grupos(todas())) {
    rel.grupos++;
    const ocupadas = comp.filter((v) => v.ocupanteId).sort((a, b) => (a.desde || 0) - (b.desde || 0));
    const fica = ocupadas[0] || comp.slice().sort((a, b) => pontos(b) - pontos(a) || Number(a.id) - Number(b.id))[0];
    const remover = [];
    const conflito = [];
    for (const v of comp) {
      if (v === fica) continue;
      if (v.ocupanteId && v.ocupanteId !== fica.ocupanteId) conflito.push(v);
      else remover.push(v);
    }
    if (conflito.length) rel.conflitos.push([fica, ...conflito]);
    if (!remover.length) continue;

    for (const v of remover) rel.removidas.push({ removida: v, manter: fica });
    if (!corrigir) continue;

    const doador = remover.slice().sort((a, b) => pontos(b) - pontos(a))[0];
    if (!fica.grupo && doador.grupo) fica.grupo = doador.grupo;
    if (!fica.foto && doador.foto) fica.foto = doador.foto;
    if ((!fica.ext || !fica.ext.startsWith('al:')) && doador.ext && doador.ext.startsWith('al:')) fica.ext = doador.ext;
    db.set(`vagas.lista.${fica.id}`, fica);
    for (const v of remover) {
      for (const p of pedidos()) if (p.vagaId === v.id) db.set(`vagas.pedidos.${p.id}`, { ...p, vagaId: fica.id });
      apagar(v.id);
    }
  }
  return rel;
}

module.exports = { auditar };
