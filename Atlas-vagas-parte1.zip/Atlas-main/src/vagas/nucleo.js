// Controle de vagas da house. Este arquivo só junta as peças (o resto do bot importa daqui):
//   util.js       textos padrão, configuração, normalização
//   banco.js      leitura/gravação de vagas e pedidos
//   identidade.js "é o mesmo personagem?" (corrige o bug da vaga ocupada contada como livre)
//   ocupacao.js   ocupar, liberar, registro vindo da recepção
//   painel.js     painel fixo de vagas
//   pedidos.js    botões e cartão dos pedidos
//   auditoria.js  acha e arruma personagens duplicados
module.exports = {
  ...require('./util'),
  ...require('./banco'),
  ...require('./identidade'),
  ...require('./ocupacao'),
  ...require('./painel'),
  ...require('./pedidos'),
  ...require('./auditoria'),
};
