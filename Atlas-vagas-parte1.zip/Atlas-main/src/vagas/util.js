// Utilidades do sistema de vagas: cor, textos padrão, configuração e normalização de texto.
const db = require('../db');

const COR = 0xf5a3c7;

const PADROES = {
  mensagens: {
    painel: {
      titulo: '📋 Vagas da house',
      texto: 'Veja abaixo os personagens que já têm dono.\nQualquer personagem que não esteja aqui está livre! Para pedir um, use `/vaga pedir` e busque pelo nome.',
    },
  },
};

const cfg = (chave, padrao) => db.get(`config.vagas.${chave}`, padrao);
const mensagem = (tipo) => ({ ...PADROES.mensagens[tipo], ...(cfg(`mensagens.${tipo}`) || {}) });
const limite = () => Number(cfg('limite', 1));

function norm(txt) {
  return String(txt || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[_*~`|]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

module.exports = { COR, PADROES, cfg, mensagem, limite, norm };
