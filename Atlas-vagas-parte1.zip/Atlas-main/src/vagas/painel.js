// Painel fixo de vagas (embeds paginados que se atualizam sozinhos).
const { EmbedBuilder } = require('discord.js');
const db = require('../db');
const { COR, cfg, mensagem, norm } = require('./util');
const { todas } = require('./banco');
const { mesmoPersonagem } = require('./identidade');

const LIMITE_PAGINA = 3600;

// Entradas que aparecem no painel: some a entrada "livre" que é gêmea de uma ocupada
function listaDoPainel() {
  const lista = todas();
  const ocupadas = lista.filter((v) => v.ocupanteId);
  return lista.filter((v) => v.ocupanteId || !ocupadas.some((o) => mesmoPersonagem(o, v)));
}

// Divide a lista em páginas de texto (uma obra por bloco, ocupadas e livres)
function paginasPainel(lista) {
  const ordenada = lista.slice().sort((a, b) => norm(a.grupo || 'geral').localeCompare(norm(b.grupo || 'geral')) || norm(a.nome).localeCompare(norm(b.nome)));
  const paginas = [];
  let atual = '';
  let grupoAtual = null;
  const empurra = () => { if (atual) paginas.push(atual); atual = ''; };
  for (const v of ordenada) {
    const g = v.grupo || 'Geral';
    const linha = v.ocupanteId ? `🔴 ${v.nome} — <@${v.ocupanteId}>` : `🟢 ${v.nome} — livre`;
    const troca = g !== grupoAtual;
    let cont = false;
    if (atual && atual.length + (troca ? g.length + 8 : 0) + linha.length + 1 > LIMITE_PAGINA) {
      empurra();
      cont = !troca;
    }
    if (troca || cont) {
      atual += `${atual ? '\n' : ''}**${g}${cont ? ' (cont.)' : ''}**\n`;
      grupoAtual = g;
    }
    atual += `${linha}\n`;
  }
  empurra();
  return paginas;
}

// Lista de embeds do painel (cada uma vira uma mensagem; o limite do Discord é por mensagem)
function embedsPainel() {
  const m = mensagem('painel');
  const lista = listaDoPainel();
  const paginas = paginasPainel(lista);
  const ocupadas = lista.filter((v) => v.ocupanteId).length;
  const rodape = `${ocupadas} ocupada(s)${lista.length > ocupadas ? ` · ${lista.length - ocupadas} livre(s) cadastrada(s)` : ''}`;
  if (!paginas.length) {
    return [new EmbedBuilder().setColor(COR).setTitle(m.titulo).setDescription(`${String(m.texto).slice(0, 600)}\n\nNenhum personagem ocupado ainda.`)];
  }
  return paginas.map((txt, i) => {
    const e = new EmbedBuilder().setColor(COR).setDescription(i === 0 ? `${String(m.texto).slice(0, 400)}\n\n${txt}` : txt);
    if (i === 0) e.setTitle(m.titulo);
    if (i === paginas.length - 1) e.setFooter({ text: rodape });
    return e;
  });
}
const embedPainel = () => embedsPainel()[0];

async function atualizarPainel(guild) {
  const canalId = cfg('canalPainel');
  if (!canalId) return false;
  const canal = guild.channels.cache.get(canalId);
  if (!canal) return false;
  const embeds = embedsPainel();
  let ids = cfg('painelMsgIds') || (cfg('painelMsgId') ? [cfg('painelMsgId')] : []);
  if (cfg('painelCanalId') !== canalId) ids = [];
  const novos = [];
  for (let i = 0; i < embeds.length; i++) {
    const payload = { embeds: [embeds[i]], allowedMentions: { parse: [] } };
    const msg = ids[i] ? await canal.messages.fetch(ids[i]).catch(() => null) : null;
    if (msg) {
      await msg.edit(payload).catch(() => {});
      novos.push(msg.id);
      continue;
    }
    try {
      const nova = await canal.send(payload);
      novos.push(nova.id);
    } catch {
      return false;
    }
  }
  for (const extra of ids.slice(embeds.length)) {
    const m = await canal.messages.fetch(extra).catch(() => null);
    if (m) await m.delete().catch(() => {});
  }
  db.set('config.vagas.painelMsgIds', novos);
  db.set('config.vagas.painelCanalId', canal.id);
  db.remover('config.vagas.painelMsgId');
  return true;
}

module.exports = { listaDoPainel, embedsPainel, embedPainel, atualizarPainel };
