// Ocupar e liberar vagas (e o cargo de ocupante).
const { cfg } = require('./util');
const {
  salvar, apagar, doUsuario, proximoId, obter,
} = require('./banco');
const { chaveManual, acharTodos } = require('./identidade');
const { atualizarPainel } = require('./painel');

async function mexerCargo(guild, userId, dar) {
  const cargoId = cfg('cargo');
  if (!cargoId) return;
  const membro = await guild.members.fetch(userId).catch(() => null);
  if (!membro) return;
  if (dar) {
    await membro.roles.add(cargoId).catch(() => {});
  } else if (doUsuario(userId).length === 0) {
    await membro.roles.remove(cargoId).catch(() => {}); // só tira se não sobrou nenhuma vaga
  }
}

// Devolve { ok: true } ou { ok: false, por, vaga } quando o personagem já tem dono (nesta entrada ou numa gêmea).
async function ocupar(guild, vaga, userId) {
  const atual = obter(vaga.id) || vaga;
  const dono = [atual, ...acharTodos(atual)].find((v) => v.ocupanteId && v.ocupanteId !== userId);
  if (dono) return { ok: false, por: dono.ocupanteId, vaga: dono };
  const jaEra = atual.ocupanteId === userId;
  atual.ocupanteId = userId;
  if (!jaEra || !atual.desde) atual.desde = Date.now();
  salvar(atual);
  await mexerCargo(guild, userId, true);
  await atualizarPainel(guild);
  return { ok: true, vaga: atual };
}

async function liberar(guild, vaga) {
  const antigo = vaga.ocupanteId;
  vaga.ocupanteId = null;
  vaga.desde = null;
  salvar(vaga);
  if (antigo) await mexerCargo(guild, antigo, false);
  if (vaga.auto) apagar(vaga.id); // vaga criada por pedido some quando fica livre
  await atualizarPainel(guild);
  return antigo;
}

// Registra o personagem que o membro fechou na recepção (não passa por pedido nem pelo limite).
// Devolve { ok, vaga } ou { pulou: motivo }. Nunca tira um personagem de outra pessoa.
async function registrarDaRecepcao(guild, userId, personagem) {
  const nome = String(personagem || '').trim();
  if (!nome) return { pulou: 'sem nome' };
  const iguais = acharTodos({ ext: chaveManual(nome, ''), nome, grupo: '' });
  if (iguais.some((v) => v.ocupanteId === userId)) return { pulou: 'ja-registrado' };
  const ocupada = iguais.find((v) => v.ocupanteId);
  if (ocupada) return { pulou: 'ocupado', vaga: ocupada };
  let vaga = iguais[0];
  if (!vaga) {
    vaga = { id: proximoId(), nome, grupo: '', ext: chaveManual(nome, ''), auto: true, ocupanteId: null, desde: null };
    salvar(vaga);
  }
  const r = await ocupar(guild, vaga, userId);
  return r.ok ? { ok: true, vaga } : { pulou: 'ocupado', vaga: r.vaga };
}

module.exports = { mexerCargo, ocupar, liberar, registrarDaRecepcao };
