// Pedidos de vaga: botões, cartão do pedido e busca de pedido repetido.
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { COR } = require('./util');
const { obter, pedidos } = require('./banco');
const { mesmoPersonagem } = require('./identidade');

function botoesPedido(id, desligados) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`vaga:aprovar:${id}`).setLabel('Aprovar').setEmoji('✅').setStyle(ButtonStyle.Success).setDisabled(!!desligados),
    new ButtonBuilder().setCustomId(`vaga:recusar:${id}`).setLabel('Recusar').setEmoji('❌').setStyle(ButtonStyle.Danger).setDisabled(!!desligados),
  );
}

// Nome, obra e foto do que está sendo pedido (vaga já cadastrada ou personagem novo)
function infoPedido(p, vaga) {
  if (vaga) return { nome: vaga.nome, grupo: vaga.grupo || '', foto: vaga.foto || null };
  if (p.novo) return { nome: p.novo.nome, grupo: p.novo.grupo || '', foto: p.novo.foto || null };
  return { nome: '(removida)', grupo: '', foto: null };
}

// Procura outro pedido em aberto pelo mesmo personagem (não só pela mesma chave)
function pedidoPendente(alvo, chave) {
  return pedidos().find((p) => {
    if (chave && p.chave === chave) return true;
    const base = p.vagaId ? obter(p.vagaId) : p.novo;
    return !!base && mesmoPersonagem({ ext: p.chave, nome: base.nome, grupo: base.grupo }, alvo);
  }) || null;
}

function embedPedido(p, vaga, estado) {
  const i = infoPedido(p, vaga);
  const origem = p.novo ? (p.novo.ext ? ' · achado no AniList' : ' · digitado à mão, confira se existe') : '';
  const emb = new EmbedBuilder()
    .setColor(estado === 'aprovado' ? 0x57f287 : estado === 'recusado' ? 0xed4245 : COR)
    .setTitle('📨 Pedido de vaga')
    .setDescription(`**Membro:** <@${p.userId}>\n**Personagem:** ${i.nome}${i.grupo ? `\n**Obra:** ${i.grupo}` : ''}${p.obs ? `\n**Observação:** ${p.obs}` : ''}`)
    .setFooter({ text: `Pedido #${p.id}${origem}` });
  if (i.foto) emb.setThumbnail(i.foto);
  if (estado) emb.addFields({ name: 'Resultado', value: `${estado === 'aprovado' ? '✅ Aprovado' : '❌ Recusado'} por <@${p.porId}>` });
  return emb;
}

module.exports = { botoesPedido, infoPedido, pedidoPendente, embedPedido };
